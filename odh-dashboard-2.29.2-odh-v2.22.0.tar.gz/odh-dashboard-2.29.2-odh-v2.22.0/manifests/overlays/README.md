# Overlay Manifests

These are shared modifications to existing deployments. These set of folders are to be considered for custom deployments or modifications to existing deployments to suit adhoc and non-operator default deployments.

> **Note:** Consider making overlays inside each deployment if your overlay is non-generic.

Each overlay should come with a readme to help with the use-case for it.
