# Dev Overlay

Allows for custom direct deployments of the min-viable resources. Used by the custom deployment install without the operator.
