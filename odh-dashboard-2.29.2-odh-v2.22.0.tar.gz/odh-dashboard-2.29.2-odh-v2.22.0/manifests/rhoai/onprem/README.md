# RHOAI OnPrem Deployment

This is the starting location for RHOAI onprem manifests.

Only add items to this folder that are exclusively onprem manifests.

> **Note:** See [`../shared`](../shared/README.md) for common items between RHOAI deployments.
