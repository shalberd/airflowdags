# RHOAI Shared Manifests

These are all the manifests that are shared between all of the RHOAI deployments.
