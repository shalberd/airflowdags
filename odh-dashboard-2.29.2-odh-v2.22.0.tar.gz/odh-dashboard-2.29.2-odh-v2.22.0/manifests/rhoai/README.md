# RHOAI Manifests

These manifests are only for RHOAI. Overrides can be performed on the manifest files in [`../core-bases`](../core-bases/README.md).
