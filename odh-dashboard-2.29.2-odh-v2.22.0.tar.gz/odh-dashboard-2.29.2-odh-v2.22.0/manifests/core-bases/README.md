# Core-Bases Manifests

These are manifest files that are intended to be used in part by other deployments and configured for their own use-cases.

> **Note:** There should be note root `kustomization.yaml` as each folder should be treated as a specific target for inclusion or overrides.
