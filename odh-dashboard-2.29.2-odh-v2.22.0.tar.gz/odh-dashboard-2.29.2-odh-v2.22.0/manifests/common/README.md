# Common Manifests

These are manifests that are shared in both ODH & RHOAI deployments.

These files are not intended to be the base of overriding or changing in any way. These should be immutable between both RHOAI and ODH deployments.

> **Note:** See the [`../core-bases`](../core-bases/README.md) folder for those that can be overridden
