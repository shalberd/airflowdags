export const environment = {
  production: true,
  apiUrl: '/tensorboard',
  resource: 'tensorboards',
  token: '',
};
