export enum DashboardState {
  Connecting = 0,
  Connected,
  Disconnected,
}
