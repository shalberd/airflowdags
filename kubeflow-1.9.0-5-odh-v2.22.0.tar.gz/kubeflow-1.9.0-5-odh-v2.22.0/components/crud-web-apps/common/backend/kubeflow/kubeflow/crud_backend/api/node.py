from . import v1_core


def list_nodes():
    return v1_core.list_node()
