This folder contains all licenses and source code of third-party dependencies for distributing the Notebook controller image.

For any dependency changes, please follow [this instruction](https://github.com/kubeflow/testing/blob/master/py/kubeflow/testing/go-license-tools/README.md) to update the content of this folder.
