export const PARENT_CONNECTED_EVENT: 'parent-connected';
export const APP_CONNECTED_EVENT: 'iframe-connected';
export const NAMESPACE_SELECTED_EVENT: 'namespace-selected';
export const ALL_NAMESPACES_EVENT: 'all-namespaces';
export const MESSAGE: 'message';
