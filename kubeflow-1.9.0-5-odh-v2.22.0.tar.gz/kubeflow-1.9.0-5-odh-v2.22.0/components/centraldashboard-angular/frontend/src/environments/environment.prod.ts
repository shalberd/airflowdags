export const environment = {
  production: true,
  buildVersion: '@BUILD_VERSION@',
};
