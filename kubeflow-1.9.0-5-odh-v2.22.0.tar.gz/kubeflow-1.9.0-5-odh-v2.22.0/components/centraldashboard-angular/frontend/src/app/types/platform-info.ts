export interface PlatformInfo {
  provider?: string;
  providerName?: string;
  buildLabel?: string;
  buildVersion?: string;
  buildId?: string;
}
