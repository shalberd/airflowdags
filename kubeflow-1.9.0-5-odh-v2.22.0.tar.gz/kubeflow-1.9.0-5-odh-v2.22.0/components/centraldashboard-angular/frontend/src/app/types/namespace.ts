export interface Namespace {
  user?: string;
  namespace: string;
  role?: string;
  disabled?: boolean;
}
